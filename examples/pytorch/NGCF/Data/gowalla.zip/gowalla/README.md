This is the check-in dataset obtained from Gowalla, where users share their locations by checking-in. To ensure the quality of the dataset, we use the 10-core setting,i.e.,retaining users and items with at least ten interactions. The dataset is downloaded from the public codes for [Neural Graph Collaborative Filtering](https://github.com/xiangwang1223/neural_graph_collaborative_filtering).

Look for the full dataset?
Please visit the [website](https://snap.stanford.edu/data/loc-gowalla.html).
